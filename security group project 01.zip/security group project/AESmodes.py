from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad
import time
import json

DATA_SIZES = {
    "1KB": 1024,
    "1MB": 1024 * 1024,
    "10MB": 10 * 1024 * 1024
}

MODES = ["ECB", "CBC", "CTR", "GCM"]
RUNS = 5

key = get_random_bytes(16)

def encrypt_data(mode, data):
    if mode == "ECB":
        cipher = AES.new(key, AES.MODE_ECB)
        return cipher.encrypt(pad(data, AES.block_size))
    elif mode == "CBC":
        iv = get_random_bytes(16)
        cipher = AES.new(key, AES.MODE_CBC, iv=iv)
        return cipher.encrypt(pad(data, AES.block_size))
    elif mode == "CTR":
        cipher = AES.new(key, AES.MODE_CTR)
        return cipher.encrypt(data)
    elif mode == "GCM":
        cipher = AES.new(key, AES.MODE_GCM)
        ciphertext, tag = cipher.encrypt_and_digest(data)
        return ciphertext
    
results = {
    "time": {mode: [] for mode in MODES},
    "throughput": {mode: [] for mode in MODES}
}

print(" AES EXPERIMENT START")

for lable, size in DATA_SIZES.items():
    print(f"\n--- Testing {lable} ---")

    data = get_random_bytes(size)

    for mode in MODES:
        total_time = 0

        for _ in range(RUNS):
            start = time.perf_counter()
            encrypt_data(mode, data)
            end = time.perf_counter()
            total_time += (end - start)

        avg_time = total_time / RUNS
        throughput = size / avg_time

        results["time"][mode].append(avg_time)
        results["throughput"][mode].append(throughput)

        print(f"{mode}: {avg_time:.6f}s | {throughput:.2f} B/s")

    with open("results.json", "w") as f:
       json.dump(results, f, indent=4)

    print("\nResults saved to results.json")
    print(" AES EXPERIMENT COMPLETE")        
        
