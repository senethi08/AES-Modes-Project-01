import json
import matplotlib.pyplot as plt


with open("results.json", "r") as f:
    results = json.load(f)

MODES = ["ECB", "CBC", "CTR", "GCM"]
sizes_labels = ["1KB", "1MB", "10MB"]


plt.figure()
for mode in MODES:
    plt.plot(sizes_labels, results["time"][mode], marker='o', label=mode)

plt.title("AES Modes - Average Encryption Time")
plt.xlabel("Data Size")
plt.ylabel("Time (seconds)")
plt.legend()
plt.grid()
plt.show()


plt.figure()
for mode in MODES:
    plt.plot(sizes_labels, results["throughput"][mode], marker='o', label=mode)

plt.title("AES Modes - Throughput")
plt.xlabel("Data Size")
plt.ylabel("Bytes per second")
plt.legend()
plt.grid()
plt.show()