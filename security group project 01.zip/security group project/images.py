from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad
from PIL import Image, ImageDraw
import numpy as np




img = Image.new("RGB", (512, 512), "white")
draw = ImageDraw.Draw(img)

brick_w, brick_h = 64, 32

for y in range(0, 512, brick_h):
    for x in range(0, 512, brick_w):
        offset = (y // brick_h) % 2 * (brick_w // 2)
        draw.rectangle(
            [x + offset, y, x + brick_w + offset, y + brick_h],
            fill=(150, 50, 50),
            outline="black"
        )

img.save("brick.png")
print("Brick wall created!")




img = Image.open("brick.png").convert("RGB")
img_data = np.array(img)
data = img_data.tobytes()


key = get_random_bytes(16)


modes = ["ECB", "CBC", "CTR", "GCM"]




for mode in modes:

    if mode == "ECB":
        cipher = AES.new(key, AES.MODE_ECB)
        encrypted = cipher.encrypt(pad(data, AES.block_size))

    elif mode == "CBC":
        iv = get_random_bytes(16)
        cipher = AES.new(key, AES.MODE_CBC, iv=iv)
        encrypted = cipher.encrypt(pad(data, AES.block_size))

    elif mode == "CTR":
        cipher = AES.new(key, AES.MODE_CTR)
        encrypted = cipher.encrypt(data)

    elif mode == "GCM":
        cipher = AES.new(key, AES.MODE_GCM)
        encrypted, tag = cipher.encrypt_and_digest(data)

    
    
    
    enc_array = np.frombuffer(encrypted[:len(data)], dtype=np.uint8)
    enc_array = enc_array.reshape(img_data.shape)

    enc_img = Image.fromarray(enc_array)
    enc_img.save(f"encrypted_{mode}.png")

    print(f"{mode} image created!")